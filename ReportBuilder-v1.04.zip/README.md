# Report Builder

A professional C# Blazor application for generating customizable PDF reports.

## Quick Start

### Extract and Run
1. Extract this ZIP file to a folder
2. Open the `dist\app` folder
3. Double-click `ReportBuilder.Web.exe`
4. Your default browser will open to `http://localhost:5000`

### Create Shortcuts (Optional)
1. Run `Install.bat` to create Start Menu and Desktop shortcuts
2. This requires administrator privileges for best results

## System Requirements

- Windows 7 or later (64-bit)
- No other software needs to be installed (all dependencies are included)

## First Run

The application may take a few seconds to start on the first run. This is normal.

## Documentation

Local documentation is included in the `documentation` folder. Open `documentation/index.html` in a web browser to access offline guides.

## Troubleshooting

**Browser doesn't open automatically**
- Open your web browser and navigate to `http://localhost:5000` manually

**Application won't start**
- Ensure the entire ZIP was extracted properly
- Try running as administrator
- Check that port 5000 is not in use

**To stop the application**
- Close the application window (not just the command console)

## Support

For issues or feature requests, visit:
https://github.com/jackrlehman/lehman.reports/issues
