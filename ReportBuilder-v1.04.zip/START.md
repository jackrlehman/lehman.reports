# Getting Started

## First Time Setup

1. **Extract Files** - Make sure this entire `dist` folder is extracted
2. **Run Application** - Navigate to the `app` folder and double-click `ReportBuilder.Web.exe`
3. **Wait for Startup** - The app may take 5-10 seconds to start on first run
4. **Browser Opens** - Your browser will automatically open to `http://localhost:5000`

## Optional: Create Desktop Shortcuts

Run `Install.bat` to create convenient shortcuts:
- **Start Menu** - Quick access from Windows Start menu
- **Desktop** - Shortcut on your desktop

*Note: Administrator privileges may be required for shortcuts*

## Using the Application

Once the app opens, you can:
- Import PDF reports
- Generate new reports with mobile app analytics
- Export customized reports

## Documentation

Complete documentation is available in the `documentation` folder. Open `documentation/index.html` in your web browser for:
- Feature guides
- Setup instructions
- FAQ and troubleshooting
- Development documentation

## Need Help?

- Check `documentation/index.html` for guides
- Visit: https://github.com/jackrlehman/lehman.reports/issues
